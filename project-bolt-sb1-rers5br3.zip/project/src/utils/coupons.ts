import Cookies from 'js-cookie';
import { addHours, isAfter, formatDistanceToNow } from 'date-fns';
import { Coupon, ClaimStatus } from '../types';
import { supabase } from './supabase';

const COOKIE_NAME = 'last_coupon_claim';
const CLAIM_COOLDOWN_HOURS = 1;

// Enhanced coupon list with more variety and better descriptions
export const coupons: Coupon[] = [
  { 
    id: '1', 
    code: 'SPRING25', 
    discount: 25, 
    description: 'Spring Special: 25% off your entire purchase' 
  },
  { 
    id: '2', 
    code: 'SUMMER30', 
    discount: 30, 
    description: 'Summer Sale: 30% discount on all items' 
  },
  { 
    id: '3', 
    code: 'FLASH40', 
    discount: 40, 
    description: 'Flash Deal: 40% off - Limited time offer!' 
  },
  { 
    id: '4', 
    code: 'MEGA50', 
    discount: 50, 
    description: 'Mega Savings: 50% off your order' 
  },
  { 
    id: '5', 
    code: 'SPECIAL60', 
    discount: 60, 
    description: 'Special Deal: Amazing 60% discount' 
  }
];

let currentCouponIndex = 0;

// Enhanced round-robin distribution with index persistence
export const getNextCoupon = (): Coupon => {
  const coupon = coupons[currentCouponIndex];
  currentCouponIndex = (currentCouponIndex + 1) % coupons.length;
  
  // Store the current index in localStorage for persistence
  localStorage.setItem('currentCouponIndex', currentCouponIndex.toString());
  return coupon;
};

// Initialize the coupon index from localStorage if available
const savedIndex = localStorage.getItem('currentCouponIndex');
if (savedIndex !== null) {
  currentCouponIndex = parseInt(savedIndex, 10);
}

const getClientIP = async (): Promise<string> => {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    if (!response.ok) {
      throw new Error('Failed to fetch IP address');
    }
    const data = await response.json();
    return data.ip;
  } catch (error) {
    console.error('Error fetching IP:', error);
    throw new Error('Unable to verify client identity. Please try again later.');
  }
};

export const checkClaimEligibility = async (): Promise<ClaimStatus> => {
  try {
    // Enhanced cookie-based restriction check
    const lastClaim = Cookies.get(COOKIE_NAME);
    if (lastClaim) {
      const lastClaimDate = new Date(lastClaim);
      const nextClaimTime = addHours(lastClaimDate, CLAIM_COOLDOWN_HOURS);
      const now = new Date();

      if (!isAfter(now, nextClaimTime)) {
        return {
          canClaim: false,
          nextClaimTime,
          message: `Please wait ${formatDistanceToNow(nextClaimTime)} before claiming another coupon.`
        };
      }
    }

    // Enhanced IP-based restriction check
    const ip_address = await getClientIP();
    
    const { data: claims, error } = await supabase
      .from('coupon_claims')
      .select('claimed_at')
      .eq('ip_address', ip_address)
      .order('claimed_at', { ascending: false })
      .limit(1);

    if (error) {
      throw new Error('Unable to verify claim eligibility. Please try again later.');
    }

    if (claims && claims.length > 0) {
      const lastClaimDate = new Date(claims[0].claimed_at);
      const nextClaimTime = addHours(lastClaimDate, CLAIM_COOLDOWN_HOURS);
      const now = new Date();

      if (!isAfter(now, nextClaimTime)) {
        const timeRemaining = formatDistanceToNow(nextClaimTime);
        return {
          canClaim: false,
          nextClaimTime,
          message: `You've recently claimed a coupon. Please wait ${timeRemaining} before claiming another.`
        };
      }
    }

    return { 
      canClaim: true, 
      message: 'You can claim your coupon now!' 
    };
  } catch (error) {
    console.error('Error checking eligibility:', error);
    throw error;
  }
};

export const recordCouponClaim = async (couponCode: string): Promise<void> => {
  try {
    // Enhanced cookie tracking with secure flags
    Cookies.set(COOKIE_NAME, new Date().toISOString(), { 
      expires: 1,
      secure: true,
      sameSite: 'strict'
    });

    const ip_address = await getClientIP();
    
    const { error } = await supabase
      .from('coupon_claims')
      .insert([
        {
          ip_address,
          coupon_code: couponCode
        }
      ]);

    if (error) {
      throw new Error('Failed to record your coupon claim. Please try again.');
    }
  } catch (error) {
    console.error('Error recording claim:', error);
    throw error;
  }
};