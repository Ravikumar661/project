import React, { useState, useEffect } from 'react';
import { Timer, Gift, AlertCircle } from 'lucide-react';
import { CouponCard } from './components/CouponCard';
import { checkClaimEligibility, getNextCoupon, recordCouponClaim } from './utils/coupons';
import { Coupon } from './types';

function App() {
  const [claimedCoupon, setClaimedCoupon] = useState<Coupon | null>(null);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [nextClaimTime, setNextClaimTime] = useState<Date | null>(null);

  useEffect(() => {
    const checkEligibility = async () => {
      try {
        const eligibility = await checkClaimEligibility();
        if (!eligibility.canClaim) {
          setMessage(eligibility.message);
          setNextClaimTime(eligibility.nextClaimTime || null);
        }
      } catch (error) {
        console.error('Error checking eligibility:', error);
      }
    };

    checkEligibility();
  }, []);

  const handleClaimCoupon = async () => {
    setIsLoading(true);
    setIsError(false);
    setMessage('');
    
    try {
      const eligibility = await checkClaimEligibility();
      
      if (eligibility.canClaim) {
        const coupon = getNextCoupon();
        await recordCouponClaim(coupon.code);
        setClaimedCoupon(coupon);
        setMessage('🎉 Congratulations! Here\'s your exclusive coupon:');
        setNextClaimTime(null);
      } else {
        setMessage(eligibility.message);
        setNextClaimTime(eligibility.nextClaimTime || null);
        setIsError(true);
      }
    } catch (error) {
      setIsError(true);
      setMessage(error instanceof Error ? error.message : 'An unexpected error occurred. Please try again later.');
      console.error('Error claiming coupon:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <Gift className="mx-auto h-16 w-16 text-indigo-600" />
          <h1 className="mt-6 text-4xl font-extrabold text-gray-900">
            Exclusive Coupon Offers
          </h1>
          <p className="mt-2 text-lg text-gray-600">
            Claim your special discount coupon now!
          </p>
        </div>

        <div className="flex flex-col items-center justify-center space-y-8">
          {!claimedCoupon && (
            <button
              onClick={handleClaimCoupon}
              disabled={isLoading || !!nextClaimTime}
              className={`
                px-6 py-3 rounded-full text-white font-semibold text-lg
                transition-all duration-200 ease-in-out transform
                ${isLoading || nextClaimTime
                  ? 'bg-gray-400 cursor-not-allowed opacity-75'
                  : 'bg-indigo-600 hover:bg-indigo-700 hover:scale-105 active:scale-95'}
              `}
            >
              {isLoading ? (
                <div className="flex items-center">
                  <Timer className="animate-spin mr-2" />
                  Processing...
                </div>
              ) : nextClaimTime ? (
                <div className="flex items-center">
                  <Timer className="mr-2" />
                  Wait for next claim
                </div>
              ) : (
                'Claim Your Coupon'
              )}
            </button>
          )}

          {message && (
            <div className={`
              flex items-center text-center text-lg p-4 rounded-lg
              ${isError ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}
            `}>
              {isError && <AlertCircle className="mr-2 h-5 w-5" />}
              {message}
            </div>
          )}

          {claimedCoupon && (
            <div className="animate-fade-in">
              <CouponCard coupon={claimedCoupon} />
            </div>
          )}

          <div className="mt-8 space-y-2 text-sm text-gray-500 text-center">
            <p>• Limited to one coupon claim per hour per user</p>
            <p>• Coupons are distributed fairly in a round-robin fashion</p>
            <p>• IP address tracking is enabled to prevent multiple claims</p>
            <p>• Browser session tracking helps maintain claim limits</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;