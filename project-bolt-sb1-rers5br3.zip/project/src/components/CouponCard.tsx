import React from 'react';
import { Ticket, Copy, Check } from 'lucide-react';
import { Coupon } from '../types';

interface CouponCardProps {
  coupon: Coupon;
}

export const CouponCard: React.FC<CouponCardProps> = ({ coupon }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(coupon.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code:', err);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-sm w-full transform transition-all duration-300 hover:shadow-xl">
      <div className="flex items-center justify-center mb-4">
        <Ticket className="w-12 h-12 text-indigo-600" />
      </div>
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-2">
          <h3 className="text-2xl font-bold text-gray-900">{coupon.code}</h3>
          <button
            onClick={handleCopyCode}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
            title="Copy code"
          >
            {copied ? (
              <Check className="w-5 h-5 text-green-500" />
            ) : (
              <Copy className="w-5 h-5 text-gray-500" />
            )}
          </button>
        </div>
        <p className="text-4xl font-bold text-indigo-600">{coupon.discount}% OFF</p>
        <p className="text-gray-600">{coupon.description}</p>
        <div className="pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-500">
            Use this code at checkout to receive your discount
          </p>
        </div>
      </div>
    </div>
  );
};