export interface Coupon {
  id: string;
  code: string;
  discount: number;
  description: string;
}

export interface ClaimStatus {
  canClaim: boolean;
  nextClaimTime?: Date;
  message: string;
}

export interface CouponClaim {
  id: string;
  ip_address: string;
  coupon_code: string;
  claimed_at: string;
}