/*
  # Create claims tracking table

  1. New Tables
    - `coupon_claims`
      - `id` (uuid, primary key)
      - `ip_address` (text)
      - `coupon_code` (text)
      - `claimed_at` (timestamp)
  2. Security
    - Enable RLS on `coupon_claims` table
    - Add policy for inserting claims
*/

CREATE TABLE IF NOT EXISTS coupon_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip_address text NOT NULL,
  coupon_code text NOT NULL,
  claimed_at timestamptz DEFAULT now()
);

ALTER TABLE coupon_claims ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert claims"
  ON coupon_claims
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view claims"
  ON coupon_claims
  FOR SELECT
  TO public
  USING (true);